package jobSeeker;

public class Logger 
{
    public static void error(String theErrorMessage)
    {
    	System.out.println(theErrorMessage);
    }
}
