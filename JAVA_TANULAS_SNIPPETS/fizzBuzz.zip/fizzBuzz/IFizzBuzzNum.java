package fizzBuzz;

public interface IFizzBuzzNum 
{
    public String FizzBuzzToPrint();
}
