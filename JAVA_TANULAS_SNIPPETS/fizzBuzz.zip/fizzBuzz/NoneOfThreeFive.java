package fizzBuzz;

public class NoneOfThreeFive implements IFizzBuzzNum
{
	@Override
	public String FizzBuzzToPrint() 
	{
		return FizzBuzzConstants.NONE_PRINT;
	}
}
