package fizzBuzz;

public class Five implements IFizzBuzzNum
{
	@Override
	public String FizzBuzzToPrint() 
	{
		return FizzBuzzConstants.FIVE_PRINT;
	}
}
