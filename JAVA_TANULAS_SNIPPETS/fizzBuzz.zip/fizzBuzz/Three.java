package fizzBuzz;

public class Three implements IFizzBuzzNum
{
	@Override
	public String FizzBuzzToPrint() 
	{
		return FizzBuzzConstants.THREE_PRINT;
	}
}
