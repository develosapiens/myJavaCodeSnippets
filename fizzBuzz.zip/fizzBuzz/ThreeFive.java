package fizzBuzz;

public class ThreeFive implements IFizzBuzzNum
{
	@Override
	public String FizzBuzzToPrint() 
	{
		return FizzBuzzConstants.THREEFIVE_PRINT;
	}
}
