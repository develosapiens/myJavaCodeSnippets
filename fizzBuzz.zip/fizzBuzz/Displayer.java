package fizzBuzz;

public class Displayer 
{
    public void write(String toWrite)
    {
    	System.out.println(toWrite);
    }
}
