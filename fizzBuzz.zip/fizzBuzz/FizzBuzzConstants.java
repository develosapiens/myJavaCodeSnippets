package fizzBuzz;

public class FizzBuzzConstants 
{
    public static String THREE_PRINT = "Fizz";
    public static String FIVE_PRINT = "Buzz";
    public static String THREEFIVE_PRINT = "FizzBuzz";
    public static String NONE_PRINT= null;
    public static int REQUIRED_MODULO_RESULT = 0;
}
