#!/bin/bash

clear
echo 'Ez a script bemutatja, hogy tudjuk visszaállítani a korábbi'
echo 'jó állapotot, ha a legutóbbi munkánk mégse kell.'
echo 'Vagy az utolsó módosításokat átrakni egy új branchbe, hogy'
echo 'megőrizzük a szülő branch eredeti állapotát.'
echo ''
read d
echo

. ./scriptGitInit.sh

cd elsoProject
clear

echo 'COMMAND: echo "1" > 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "1" > 1.text
echo '----------------------------------------'
echo 'Valami legyen a gitben, hogy látható legyen a változás.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo '1.text jelenleg untracked. Azaz még nincs stage-en.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
echo '----------------------------------------'
echo 'Egyelőre egy sor van a fájlban.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git add .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
echo '----------------------------------------'
echo 'untrackedből átkerül stagedbe a 1.text.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Ahogy az látszik is.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "111" >> 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "111" >> 1.text
echo '----------------------------------------'
echo 'Még egy sor hozzáadva a fájlhoz. Most a'
echo 'staged fájban csak egy sor van, az utolsó'
echo 'módosítással a fájlrendszeren lévőben kettő.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'new állapotban és modified állapotban is van'
echo 'ugyanaz a fájl. Azaz a fájlrendszeren egy'
echo 'másik verziója van meg az adott fájlnak, mint'
echo 'a stage-en.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
echo '----------------------------------------'
echo 'látható, hogy két sort tartalmaz a fájl-'
echo 'rendszeren levő 1.text.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git diff'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git diff
echo '----------------------------------------'
echo 'git diff paraméter nélkül hívva a fájlrendszer'
echo 'és a staged verziót hasonlítja össze.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git checkout .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout .
echo '----------------------------------------'
echo 'Ez az első módszer, amivel a mégse kívánt'
echo 'módosításokat ki lehet dobni.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
echo '----------------------------------------'
echo 'Csak egy sor maradt. A másodikat sikeresen kidobtuk.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git diff'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git diff
echo '----------------------------------------'
echo 'Nincs különbség már.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Már csak a new állapotú fájl maradt a'
echo 'stage-en, a fájlrendszerre is ez került vissza.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git commit -m "1.text added to local repo"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -m "1.text added to local repo"
echo '----------------------------------------'
echo 'stage-ről megy a repóba is. Úgy is mondhatjuk,'
echo 'hogy ami a fájlrendszeren van, az a stagere (add),'
echo 'majd a repóba is átkerült (commit).'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "222" >> 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "222" >> 1.text
echo '----------------------------------------'
echo 'Ismét tegyük különbözővé a fájlrendszert'
echo 'és a gites verziót.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Most nem new, nem untracked a fájl, hanem'
echo 'modified.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
echo '----------------------------------------'
echo 'Most megint két soros a fájl. Egy darabig.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git checkout HEAD .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout HEAD .
echo '----------------------------------------'
echo 'modified állapotú fájlokat felülírhatjuk így.'
echo 'Ezzel (most is) kidobva a mostanában készült változásokat.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'statusnak nincs most kimenete, azaz nincs'
echo 'semmi újság a számunkra.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
echo '----------------------------------------'
echo 'Ismét visszaállt a fájlrendszer állapota'
echo 'a korábbira, arra, ami a gitben tárolva'
echo 'van.'
echo '----------------------------------------'
echo
echo
read d


echo 'COMMAND: echo "222" >> 1.text'
echo 'COMMAND: echo "AAA" >> A.text'
echo 'COMMAND: echo "aaa" >> a.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "222" >> 1.text
echo "AAA" >> A.text
echo "aaa" >> a.text
echo '----------------------------------------'
echo 'TFH jópár fájlt készítettünk, módosítottunk,'
echo 'vagyis túl sok változás van a fájlrendszeren és'
echo 'most döbbentünk rá, hogy ezt a sok új munkát'
echo 'mégse egy jó branchben kéne kezelni, hanem'
echo 'egy sajátban, hogy az eredeti branch maradjon'
echo 'meg a korábbi, tiszta állapotában.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'vannak módosított és újonnan létrehozott fájlok.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo 'COMMAND: cat A.text'
echo 'COMMAND: cat a.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
cat A.text
cat a.text
echo '----------------------------------------'
echo 'Van is bennük mindenféle, hogy alaposan'
echo 'különbözzön a verzókezelt állapottól.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git checkout -b myOwnBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout -b myOwnBranch
echo '----------------------------------------'
echo 'Létrehozunk egy új branchet, mert mégis'
echo 'jobb, ha oda piszkítunk, a saját homokozónkba,'
echo 'mint az eredeti ágba, amit mindenki használ.'
echo 'egyúttal át is váltunk az új ágra.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git add .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
echo '----------------------------------------'
echo 'Ebben az új ágban addolunk mindent.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git checkout master'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout master
echo '----------------------------------------'
echo 'Visszamegyünk az eredeti ágra, hogy lássuk, ott mi a helyzet.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: ls'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls
echo '----------------------------------------'
echo 'Még látszanak itt is a fájlok a shared stage miatt.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git checkout myOwnBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout myOwnBranch
echo '----------------------------------------'
echo 'Lépjünk vissza a saját területünkre.'
echo '----------------------------------------'
echo
echo
read d





echo 'COMMAND: git commit -m "hozzuk át a módosított dolgokat és így őrizzük meg a mastert eredeti állapotában."'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -m "hozzuk át a módosított dolgokat és így őrizzük meg a mastert eredeti állapotában."
echo '----------------------------------------'
echo 'Amíg nem kommitoljuk itt a módosításainkat, addig'
echo '(shared stage miatt) a másik ágon is látszanak azok'
echo 'a módosítások, amiket csak itt akarunk, hogy létezzenek.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: ls'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls
echo '----------------------------------------'
echo 'kommit nélkül az ls a másik ágban is listázta'
echo 'azokat a fájlokat, amik az új módosításaink és'
echo 'amelyek miatt létrehoztuk ezt az ágat.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Látjuk, hogy valóban azon az ágon vagyunk,'
echo 'ahol az újdonságokat tudni akarjuk.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git checkout master'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout master
echo '----------------------------------------'
echo 'Átlépünk a kiinduló ágba és reméljük, hogy ott'
echo 'majd mostmár nem lesznek ott az új fájlok.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: ls'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls
echo '----------------------------------------'
echo 'Éééééééssss... Tádááám!'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: cat 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
cat 1.text
echo '----------------------------------------'
echo 'Immár ismét az eredeti állapotában van a fájl.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "egy sor" >> 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "egy sor" >> 1.text
echo '----------------------------------------'
echo 'Elkezdünk kommitokat gyártani, mert a logban'
echo 'található hash alapján is vissza lehet állni'
echo 'korábbi állapotra.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git add .'
echo 'COMMAND: git commit -m "egy kommit"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
git commit -m "egy kommit"
echo '----------------------------------------'
echo '...hogy majd legyen log'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "még egy sor" >> 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "még egy sor" >> 1.text
echo '----------------------------------------'
echo ''
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git commit -a -m "még egy kommit"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -a -m "még egy kommit"
echo '----------------------------------------'
echo '-a kapcsoló nélkül nem lenne kommit. Elé kellene git add .'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "és még egy harmadik is" >> 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "és még egy harmadik is" >> 1.text
echo '----------------------------------------'
echo ''
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git commit -a -m "és még egy harmadik kommit"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -a -m "és még egy harmadik kommit"
echo '----------------------------------------'
echo 'lesz log elég már'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git log'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git log
echo '----------------------------------------'
echo 'itt is van a  log'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git branch ujAg'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch ujAg
echo '----------------------------------------'
echo '-új branchet készíteni'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git log
'echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git log
echo '----------------------------------------'
echo '-nem lépünk át az új branchbe, mert itt akarjuk kidobni a mostanság változtatásokat'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git log | grep commit | cut -d " " -f2 | head -n 2 | tail -n 1'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git log | grep commit | cut -d " " -f2 | head -n 2 | tail -n 1
echo '----------------------------------------'
echo 'Ez az utolsó előtti kommit hash kódja.'
echo 'Erre fogunk hivatkozni.'
echo '----------------------------------------'
echo
echo
read d

KOMMITHASHKOD=$(git log | grep commit | cut -d " " -f2 | head -n 2 | tail -n 1)
echo "COMMAND: git reset --hard $KOMMITHASHKOD"
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git reset --hard $KOMMITHASHKOD
echo '----------------------------------------'
echo 'Ha minden jól mengy, nincs hibaüzenet.'
echo '----------------------------------------'
echo
echo
read d

echo "COMMAND: git log"
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git log
echo '----------------------------------------'
echo 'A legutolsó bejegyzés az kell legyen,'
echo 'ami az előbb az utolsó előtti volt még.'
echo '----------------------------------------'
echo
echo
read d

echo "COMMAND: git checkout ujAg"
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout ujAg
echo '----------------------------------------'
echo 'Átváltunk az új ágra, ahol tovább'
echo 'visszük a másikon eldobott dolgokat.'
echo '----------------------------------------'
echo
echo
read d

echo "COMMAND: git log"
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git log
echo '----------------------------------------'
echo 'Itt, ezen az ágon látszania kell az'
echo 'eredeti ágon eldobott kommitoknak is.'
echo '----------------------------------------'
echo
echo
read d

cd ..

echo
echo 'VÉGE'
echo
