#!/bin/bash

clear
echo 'Azt látjuk ebben a scriptben, hogy mi a gyakorlati különbség a'
echo 'git add .'
echo 'és a'
echo 'git commit -a'
echo 'parancsok között...'
read d
echo

. ./scriptGitInit.sh

echo 'COMMAND: git config --local --list'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git config --local --list
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo
read d

