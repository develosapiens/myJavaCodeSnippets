#!/bin/bash

clear

if [ -d begin ]
then
    rm -rf begin
fi

echo 'mkdir begin'
echo 'cd begin'
echo
mkdir begin
cd begin

echo 'COMMAND: echo "1" > 1.text'
echo 'COMMAND: echo "2" > 2.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "1" > 1.text
echo "2" > 2.text
echo '----------------------------------------'
echo 'Már meglevő fájlrendszerből készülő git repó.'
echo 'Amihez előbb fájlokra van szükség...'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git init'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git init
echo '----------------------------------------'
echo 'A fájlrendszer az előbb elkészült, most'
echo 'tegyük gitkezeltté...'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git add .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
echo '----------------------------------------'
echo 'Így lesz hozzáadva a repóhoz a sok fájlom.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'A commit még hátra van.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git commit -a -m "komit is kell..."'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -a -m "komit is kell..."
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Mi változott...'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Egyetlen branch van jelenleg.'
echo '----------------------------------------'
echo
echo

cd ..
