#!/bin/bash

clear
echo 'Azt látjuk ebben a scriptben, hogy mi a gyakorlati különbség a'
echo 'git add .'
echo 'és a'
echo 'git commit -a'
echo 'parancsok között...'
read d
echo

./scriptGitInit.sh

echo 'COMMAND: cd elsoProject'
cd elsoProject
echo
echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "1" > 1.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "1" > 1.text
echo '----------------------------------------'
echo 'Legyen valami a repóban...'
echo '----------------------------------------'
echo
echo
read l

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'A git látja a frissen létrehozott fájlt,'
echo 'amely még nem része a repónak, nem is'
echo 'gitkezelt fájl még...'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git add .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
echo '----------------------------------------'
echo 'git add . mindent hozzáad a githez, amit'
echo 'az aktuális könyvtárban talál.'
echo '----------------------------------------'
echo
echo
read l

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Már a git része az első fájl, de még nincs kommitolva...'
echo 'pusholva meg pláne nincs.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "2" > 2.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "2" > 2.text
echo '----------------------------------------'
echo 'Létrehozot fájl még ekkor nem része a gitrepónak'
echo 'semmilyen szinten sem.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git add 2.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add 2.text
echo '----------------------------------------'
echo 'Most már igen. Implicit megadva, hogy mi kerüljön'
echo 'gitkezelés alá. Ha nem mindent kell betolni a'
echo 'git alá, akkor nem git add . hanem git add fájlneve...'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'két fájlunk már a gitben van, de még se'
echo 'kommitolva, se (naná) pusholva nincsenek.'
echo 'Most vannak stage, avagy index alatt...'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "3" > 3.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "3" > 3.text
echo '----------------------------------------'
echo 'Még egy fájl született.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git commit -a -m "3. untracked"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -a -m "3. untracked"
echo '----------------------------------------'
echo 'A legutolsó ún. untracked fájl ezzel a'
echo 'paranccsal nem kerül be a gitbe.'
echo 'Törlés és változás bekerült volna, csak'
echo 'teljesen új fájl nem.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Íme erre a bizonyíték.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: echo "2B" >> 2.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "2B" >> 2.text
echo '----------------------------------------'
echo 'Egy már kezelt fájlban változás történt...'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'a második fájl már gitkezelt, de a harmadik'
echo 'még mindig nem.'
echo '2. modified, míg a 3. untracked állapotú.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git commit -a -m "3. még mindig nem kerül be a gitbe, csak a második"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -a -m "3. még mindig nem kerül be a gitbe, csak a második"
echo '----------------------------------------'
echo 'A 2. fájl változása kommitolódik, de az'
echo 'untracked 3. fájl még mindig nem kerül git alá.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Ahogyan azt a status is mutatja, a 3. fájl még'
echo 'nincs a gitben.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git add .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
echo '----------------------------------------'
echo 'Minden (jelen esetben csak a 3., legutolsó fájl)'
echo 'hozzáadódik a githez.'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'A 3. fájl immár újonnan érkezett a gitbe.'
echo '----------------------------------------'
echo
echo

echo "VÉGE"
echo