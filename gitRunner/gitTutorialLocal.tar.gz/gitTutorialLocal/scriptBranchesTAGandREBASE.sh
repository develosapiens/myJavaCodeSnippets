#!/bin/bash

. ./scriptGitInit.sh

echo
echo 'COMMAND: cd elsoProject'
cd elsoProject
echo
read r

echo 'COMMAND: echo "1" > 1.text'
echo 'COMMAND: echo "2" > 2.text'
echo 'COMMAND: echo "3" > 3.text'
echo 'COMMAND: echo "4" > 4.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "1" > 1.text
echo "2" > 2.text
echo "3" > 3.text
echo "4" > 4.text
echo '----------------------------------------'
echo 'Legyen pár fájl, amit majd a git megkap.'
echo '----------------------------------------'
echo
echo

echo 'COMMAND: git add .'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add .
echo '----------------------------------------'
echo 'untrackedből staged lesznek a fájlok.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git commit -m "négy fájl ment a repoba"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -m "négy fájl ment a repoba"
echo '----------------------------------------'
echo 'stageből bekerülnek a repóba, már csak a push lenne hátra.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git checkout -b NewBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout -b NewBranch
echo '----------------------------------------'
echo 'Új branch létrehozása és egyből át is vált oda'
echo 'ez a parancs.'
echo 'Új ág létrehozásához használható a'
echo 'git branch újBranchNeve'
echo 'vagy a'
echo 'git branch újBranchNeve branchAmibőlKészítjük'
echo 'parancs is.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Így pedig kilistázhatjuk a brancheinket.'
echo 'branch -a az összeset,'
echo 'branch -r a távoli brancheket listázza.'
echo 'Látható, hogy az új branch van használatban éppen.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: ls -1'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls -1
echo '----------------------------------------'
echo 'Örökölte azokat a fájlokat, amelyik a származtató'
echo 'branchben is megvoltak.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: echo "5" > 5.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
echo "5" > 5.text
echo '----------------------------------------'
echo 'Ez az új fájl nem lesz benne abban a branchben,'
echo 'ami alapján ezt a branchet létrehoztuk.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git add 5.text'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git add 5.text
echo '----------------------------------------'
echo 'newBranchben már bele is kerül az ötödik fájl.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo 'Nem megmondtam?'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git commit -m "5.text a repoba ment"'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git commit -m "5.text a repoba ment"
echo '----------------------------------------'
echo ''
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo ''
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: ls -1'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls -1
echo '----------------------------------------'
echo 'Itt még látjuk mind az öt fájlt.'
echo '----------------------------------------'
echo
echo

echo 'COMMAND: git push origin master'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git push origin master
echo '----------------------------------------'
echo 'Ez egy igazi push a távoli, központi repóba!'
echo '----------------------------------------'
echo
echo

echo 'COMMAND: git checkout master'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout master
echo '----------------------------------------'
echo 'Visszaváltunk a master branchbe.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: ls -1'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls -1
echo '----------------------------------------'
echo 'És bizony ebben a branchben nincs benne az 5. fájl.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Ellenőriztük, hogy valóban a master branchben vagyunk.'
echo '----------------------------------------'
echo
echo
read r


echo 'COMMAND: git checkout newBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout NewBranch
echo '----------------------------------------'
echo 'Visszaváltunk a newBranchbe.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: ls -1'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls -1
echo '----------------------------------------'
echo 'És itt ismét látható az 5. fájl.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git tag EGY NewBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git tag EGY NewBranch
echo '----------------------------------------'
echo 'NewBranch aktuális állapota lesz egy tag'
echo 'EGY néven.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git tag'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git tag
echo '----------------------------------------'
echo 'Kilistázza a tageket.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Melyik ágon is vagyunk most?'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git checkout master'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git checkout master
echo '----------------------------------------'
echo 'Váltás master ágra.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git rebase NewBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git rebase NewBranch
echo '----------------------------------------'
echo 'NewBranch különbsége (masterhez képest)'
echo 'belekerül masterbe. Ez jelenleg az 5. fájl.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: ls'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
ls
echo '----------------------------------------'
echo 'Az 5. fájl megjelent ebben az ágban? Igen.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Ez ugye a master branch?'
echo 'és ott látszik a NewBranch is.'
echo 'Most még.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch -d NewBranch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch -d NewBranch
echo '----------------------------------------'
echo 'De most kidobjuk a NewBranchet.'
echo '----------------------------------------'
echo
echo
read r

echo 'COMMAND: git branch'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git branch
echo '----------------------------------------'
echo 'Csak egy ág maradt.'
echo '----------------------------------------'
echo
echo

echo
echo "V É G E"
echo
