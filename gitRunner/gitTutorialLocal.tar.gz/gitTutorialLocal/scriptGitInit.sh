#!/bin/bash

clear

if [ -d elsoProject ]
then
    rm -rf elsoProject
fi

if [ -d masodikProject ]
then
    rm -rf masodikProject
fi

if [ -d elsoProject.git ]
then
    rm -rf elsoProject.git
fi

if [ -d masodikProject.git ]
then
    rm -rf masodikProject.git
fi

echo
echo "REMOTE SCRIPT BEGIN"
echo 
echo 'ssh viking@192.168.0.11 gitTutorialMain/createGitBaseAndProject1.sh'
ssh viking@192.168.0.11 "cd gitTutorialMain;./createGitBaseAndProject1.sh"
echo
echo "REMOTE SCRIPT END"
echo
read r


echo
echo 'COMMAND: git clone viking@192.168.0.11:gitTutorialMain/elsoProject.git'
git clone viking@192.168.0.11:gitTutorialMain/elsoProject.git
echo
echo 'COMMAND: cd elsoProject'
cd elsoProject
echo
echo 'COMMAND: git status'
git status
echo
read r
#git config --global user.name "viking"
#git config --global user.email "viking@develosapiens.net"
git config --local user.name "viking"
git config --local user.email "viking@develosapiens.net"
git config --local alias.ci "commit"

echo 'COMMAND: git config --local --list'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git config --local --list
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo 'git init script vége...'
echo 

cd ..
read r

