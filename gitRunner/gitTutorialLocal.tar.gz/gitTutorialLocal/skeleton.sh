#!/bin/bash

clear
echo 'Ez a script bemutatja, hogy '
echo ''
echo ''
read d
echo

. ./scriptGitInit.sh

cd elsoProject
clear

echo 'COMMAND: git config --local --list'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git config --local --list
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo
read d

echo 'COMMAND: git status'
echo '>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<'
git status
echo '----------------------------------------'
echo '----------------------------------------'
echo
echo
read d

cd ..

echo
echo 'VÉGE'
echo
