#!/bin/bash

cd /home/viking/gitTutorialMain

if [ -d elsoProject ]
then
    rm -rf elsoProject
fi

if [ -d masodikProject ]
then
    rm -rf masodikProject
fi

if [ -d elsoProject.git ]
then
    rm -rf elsoProject.git
fi

if [ -d masodikProject.git ]
then
    rm -rf masodikProject.git
fi

git init --bare elsoProject.git

echo 'COMMAND: ls -la'
ls -la
echo
echo 'COMMAND: pwd'
pwd
echo
