package secondBiggest;

public class Displayer 
{
    public static void writeThis(int number)
    {
    	System.out.println(number);
    }
	
    public static void writeThis(String message)
    {
    	System.out.println(message);
    }

    public static void writeError(String message)
    {
    	System.err.println(message);
    }
}
